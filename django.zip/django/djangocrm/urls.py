from django.urls.conf import include
from django.contrib import admin
from django.urls import path


urlpatterns = [
    path('admin/', admin.site.urls),
    path('홈페이지/', include('sales.urls', namespace="홈페이지")),
]
