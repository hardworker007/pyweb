from django.contrib import admin
from .models import 아이디,Sale,Person
admin.site.register(아이디)
admin.site.register(Sale)
admin.site.register(Person)

