# django_practice
